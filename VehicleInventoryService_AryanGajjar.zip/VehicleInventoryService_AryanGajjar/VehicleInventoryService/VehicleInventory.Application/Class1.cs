﻿namespace VehicleInventory.Application;

public class Class1
{

}
