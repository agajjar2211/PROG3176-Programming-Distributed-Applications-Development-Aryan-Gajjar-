﻿namespace VehicleInventory.Domain;

public class Class1
{

}
