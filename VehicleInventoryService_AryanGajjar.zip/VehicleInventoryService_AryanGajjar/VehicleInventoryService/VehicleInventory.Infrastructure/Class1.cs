﻿namespace VehicleInventory.Infrastructure;

public class Class1
{

}
